import React from 'react';

function Header(props) {
    return (
		<header>
            <div>Todo App</div>
            <div>by Min-Young</div>
        </header>
    );
}

export default Header;

